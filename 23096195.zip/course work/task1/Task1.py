#!/usr/bin/python
import sys
from mininet.node import Controller
from mininet.log import setLogLevel, info
from mn_wifi.cli import CLI
from mn_wifi.net import Mininet_wifi


def topology(plot):
    "Create a network."
    net = Mininet_wifi()

    info("*** Creating nodes\n")
    #TODO add stations and  access points
    sta1 = net.addStation('sta1', mac='00:00:00:00:00:02', ip='192.168.10.1/24', password='23096195',  position='65,150', min_v=1, max_v=5)
    sta2 = net.addStation('sta2', mac='00:00:00:00:00:03', ip='192.168.10.2/24', password='23096195',  position='74,115', min_v=5, max_v=10)
    sta3 = net.addStation('sta3', mac='00:00:00:00:00:04', ip='192.168.10.3/24', password='23096195',  position='175,65', min_v=2, max_v=7)
    ap1 = net.addAccessPoint('ap1', mac='00:00:00:00:10:02', ssid='ssid-ap1', password='23096195',  mode='g', channel='6', position='46,115', range=35, band='5')
    ap2 = net.addAccessPoint('ap2', mac='00:00:00:00:10:03', ssid='ssid-ap2', password='23096195',  mode='g', channel='6', position='90,150,0', range=35, band='5')
    ap3 = net.addAccessPoint('ap3', mac='00:00:00:00:10:04', ssid='ssid-ap3', password='23096195',  mode='g', channel='6', position='90,115,0', range=35, band='5')
    ap4 = net.addAccessPoint('ap4', mac='00:00:00:00:10:05', ssid='ssid-ap4', password='23096195',  mode='g', channel='6', position='125,50,0', range=50, band='5')
    ap5 = net.addAccessPoint('ap5', mac='00:00:00:00:10:06', ssid='ssid-ap5', password='23096195',  mode='g', channel='6', position='175,49,0', range=50,band='5')
    c1 = net.addController('c1')
    net.setPropagationModel(model="logDistance", exp=5)
    info("*** Configuring wifi nodes\n")
    net.configureWifiNodes()
    #TODO add link and plot 
    net.addLink(ap1, ap2)
    net.addLink(ap2, ap3)
    net.addLink(ap3, ap4)
    net.addLink(ap4, ap5)
    net.plotGraph(max_x=200, max_y=200)
    #TODO create a mobility scenario
    #net.plotGraph(min_x=-20, min_y=-10, max_x=90, max_y=70)
    net.startMobility(time=0)
    net.mobility(sta1, 'start', time=10, position='65,150')
    net.mobility(sta1, 'stop', time=20, position='125,65')
    net.mobility(sta2, 'start', time=30, position='74,115')
    net.mobility(sta2, 'stop', time=60, position='175,45')
    net.mobility(sta3, 'start', time=25, position='175,65')
    net.mobility(sta3, 'stop', time=60,position='75,115')
    net.stopMobility(time=120)
    info("*** Starting network\n")
    net.build()
    c1.start()
    #TODO start aps
    ap1.start([c1])
    ap2.start([c1])
    ap3.start([c1])
    ap4.start([c1])
    ap5.start([c1])
    CLI(net)

    info("*** Stopping network\n")
    net.stop()


if __name__ == '__main__':
    setLogLevel('info')
    plot = False if '-p' in sys.argv else True
    topology(plot)
    info("*** Running CLI\n")

